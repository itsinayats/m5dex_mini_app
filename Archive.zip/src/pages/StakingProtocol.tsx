import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowLeft, Zap, AlertCircle, Activity, 
  TrendingUp, Lock, Layers, BarChart3, Clock,
  PiggyBank,
  PiggyBankIcon
} from "lucide-react";
import { useAppContext } from "../context/AppContext";
import { useNavigate } from "react-router-dom";

// --- Sub-component to handle individual real-time counters ---
const StakeItem = ({ stake }: { key:any,stake: any }) => {
  const [now, setNow] = useState(Date.now());
    const {claimStake,config } = useAppContext();

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const startTime = new Date(stake.timestamp).getTime();
  const durationMs = (stake.durationDays || 30) * 24 * 60 * 60 * 1000;
  const endTime = startTime + durationMs;
  const timeLeftMs = Math.max(0, endTime - now);
  const isFinished = now >= endTime;

  const totalRoiPossible = (stake.amount * (stake.roi || 0)) / 100;
  const elapsedMs = Math.max(0, now - startTime);
  const progressRatio = Math.min(1, elapsedMs / durationMs);
  const currentEarnings = isFinished ? totalRoiPossible : totalRoiPossible * progressRatio;
  const liveTotalValue = stake.amount + currentEarnings;

  const formatTimeLeft = (ms: number) => {
    if (ms <= 0) return "00D 00H 00M 00S";
    const days = Math.floor(ms / (24 * 60 * 60 * 1000));
    const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
    const seconds = Math.floor((ms % (1000 * 60)) / 1000);
    return `${days}D ${hours}H ${minutes}M ${seconds}S`;
  };

  return (
    <div className="bg-slate-900/30 border border-slate-800 p-4 rounded-2xl flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-black border border-pink-500/20 flex items-center justify-center shrink-0">
            <Zap size={16} className={isFinished ? "text-green-400" : "text-pink-500"} />
          </div>
          <div className="flex flex-col">
            <h4 className="text-xs font-black text-white leading-tight">
             {stake.amount} <span className="text-slate-500 text-[7px] font-medium ml-1 uppercase">{config.coin_ticker}</span>
            </h4>
            <div className="flex items-center gap-1">
               <span className="text-[10px] font-mono font-bold text-pink-500 tabular-nums">
                 +{currentEarnings.toFixed(8)}
               </span>
               <span className="text-[7px] text-slate-500 uppercase font-black tracking-tighter">ROI Accrued</span>
            </div>
          </div>
        </div>
        <div className={`flex px-2 py-0.5 rounded-md border ${isFinished ? 'bg-green-500/10 border-green-500/20' : 'bg-pink-500/10 border-pink-500/20 animate-pulse'}`}>
          <span className={`text-[7px] font-black uppercase ${isFinished ? 'text-green-500' : 'text-pink-500'}`}>
            {isFinished ? 'Matured' : 'Mining'}
          </span>   
        </div>
      </div>

      <div className="flex items-center justify-between gap-4 py-3 border-y border-slate-800/50">
    {/* Time Remaining */}
    <div className="space-y-1">
        <div className="flex items-center gap-1">
            <Clock size={10} className="text-slate-500" />
            <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest">Time Remaining</p>
        </div>
        <p className="text-[10px] font-mono font-bold text-slate-200 tabular-nums uppercase">
            {isFinished ? "Matured" : formatTimeLeft(timeLeftMs)}
        </p>
    </div>

    {/* Monthly ROI */}
    <div className="space-y-1">
        <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest leading-none">Monthly ROI</p>
        <p className="text-[11px] font-mono font-bold text-white tabular-nums">
            {config.staking_monthly_roi}%
        </p>
    </div>

    {/* Live Value */}
    <div className="space-y-1 text-right">
        <p className="text-[7px] font-black text-slate-500 uppercase tracking-widest leading-none">Live Value</p>
        <p className="text-[11px] font-mono font-bold text-white tabular-nums">
            {liveTotalValue.toFixed(6)} <span className="text-[8px] text-slate-500 uppercase">{config.coin_ticker}</span>
        </p>
    </div>
</div>

      <div className="flex items-center gap-2">
      {isFinished ? (
  stake.status === "Active" ? (
    <button 
      onClick={() => claimStake(stake._id)} 
      className="inset-0 bg-gradient-to-r from-pink-600 via-purple-500 to-pink-600 flex-1 py-2 text-white border border-white/20 rounded-lg text-[8px] font-black uppercase shadow-[0_0_15px_rgba(255,255,255,0.1)] active:scale-95 transition-all"
    >
      Unstake & Claim
    </button>
  ) : (
    <button  
      className="flex-1 py-2 bg-green-500/10  text-green-500 font-bold  border border-white/10 rounded-lg text-[8px] uppercase border-green-500/20"
    >
      Claimed
    </button>
  )
) : (
  <button 
    disabled 
    className="flex-1 py-2 rounded-lg text-[8px] font-black uppercase bg-slate-900/50 border border-slate-800 text-slate-600 cursor-not-allowed"
  >
    Locked
  </button>
)}

        
      </div>
    </div>
  );
};

const StakingProtocol: React.FC = () => {
  const { user, handleStake, stakingHistory, fetchStakingHistory, isLoading,config } = useAppContext();
  const navigate = useNavigate();

  const [amount, setAmount] = useState<string>("");
  const [totalLiveEarnings, setTotalLiveEarnings] = useState(0);
    const [totalStaked, setTotalStaked] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  const availableBalance = user?.total_balance || 0;

  useEffect(() => {
    fetchStakingHistory();
  }, []);

  // --- Real-time Aggregate Earnings Logic ---
  useEffect(() => {
    const calculateAllEarnings = () => {
      const now = Date.now();
      let total = 0;
      let totalStaking = 0;
      stakingHistory.forEach((stake: any) => {
        const startTime = new Date(stake.timestamp).getTime();
        const durationMs = (stake.durationDays || 30) * 24 * 60 * 60 * 1000;
        const totalRoiPossible = (stake.amount * (stake.roi || 0)) / 100;
        const elapsedMs = Math.max(0, now - startTime);
        const progressRatio = Math.min(1, elapsedMs / durationMs);
        total += totalRoiPossible * progressRatio;
        totalStaking += stake.amount;
      });
      setTotalStaked(totalStaking);
      setTotalLiveEarnings(total);
    };
    const timer = setInterval(calculateAllEarnings, 1000);
    return () => clearInterval(timer);
  }, [stakingHistory]);

  // --- Input Validation Logic ---
  useEffect(() => {
    const numAmount = parseFloat(amount);
    const hasInsufficientFunds = numAmount > availableBalance;
    const isInvalidNumber = isNaN(numAmount) || numAmount <= 0;
    
    if (hasInsufficientFunds) {
      setError("Insufficient Balance");
    } else {
      setError(null);
    }

    setIsButtonDisabled(isLoading || isInvalidNumber || hasInsufficientFunds);
  }, [amount, availableBalance, isLoading]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) setAmount(value);
  };

  const onStakeClick = async () => {
    if (isButtonDisabled) return;
    const success = await handleStake(parseFloat(amount));
    if (success) {
        setAmount("");
        fetchStakingHistory(); // Refresh history immediately
    }
  };

  if (!user) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="px-6 space-y-6 pb-24 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between pt-6">
        <div className="flex items-center gap-4">
            <button onClick={() => navigate(-1)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-900 border-2 border-slate-800 text-slate-400">
                <ArrowLeft size={20} />
            </button>
            <div>
                <h1 className="text-[10px] font-black uppercase  text-slate-500 ">Staking Protocol</h1>
                <p className="text-sm font-black text-white uppercase">Asset_Staking</p>
            </div>
        </div>
        <div className="w-10 h-10 bg-black border-2 border-pink-900/30 rounded-xl flex items-center justify-center relative">
            <Layers size={18} className="text-pink-500" />
        </div>
      </div>

      {/* Main Portfolio Monitor */}
      <div className="relative bg-[#070B14] border-2 border-pink-900/20 rounded-[2.5rem] overflow-hidden p-8 flex flex-col items-center">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-pink-600 via-purple-400 to-pink-600 animate-pulse" />
        
        <div className="w-full flex justify-between items-center mb-6">
            <div className="px-3 py-1 bg-pink-500/10 border border-pink-500/20 rounded-full flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-pink-500 rounded-full animate-ping" />
                <span className="text-[8px] font-black text-pink-500 uppercase">Protocol_Live</span>
            </div>
            
        </div>

        <p className="text-[9px] font-black text-slate-500 uppercase tracking-[0.4em] mb-1 text-center w-full">Available_balance</p>
        <h2 className="text-4xl font-black tracking-tighter text-white tabular-nums mb-4">
          {availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
        </h2>

        <div className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div className="text-xs font-mono font-black text-green-400 tabular-nums flex flex-col items-center">
                <span className="flex flex-row "><PiggyBank size={16} className="text-green-500 mr-2" /> <span className="text-slate-500">In-Stake</span></span>
                <span className="flex flex-row text-pink-400">{totalStaked} {config.coin_ticker} </span>
            </div>
            <span className="text-xs font-mono font-black text-green-400 tabular-nums flex flex-col items-center">
              <span className="flex flex-row "><TrendingUp size={16} className="text-green-500 mr-2" /> <span className="text-slate-500">Earning</span></span>
              <span>+{(totalLiveEarnings).toFixed(6)}</span> 
            </span>
        </div>
      </div>

      {/* Stake Input Section */}
      <div className="space-y-4">
        <div className="bg-black/40 border-2 border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Enter New Stake Amount</span>
            <button onClick={() => setAmount(availableBalance.toString())} className="text-[9px] font-black text-pink-500 bg-pink-500/5 border border-pink-500/20 px-3 py-1 rounded-lg">MAX</button>
          </div>
         <div className="relative w-full">
  <input 
    type="text" 
    value={amount} 
    onChange={handleAmountChange} 
    placeholder="0.00"
    className={`w-full bg-black border-2 ${
      error ? 'border-red-500/50' : 'border-slate-800 focus:border-white/30'
    } rounded-2xl p-4 pr-16 text-2xl font-black text-white focus:outline-none font-mono transition-all`}
  />
  
  {/* Rightmost Coin Name */}
  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
    <div className="w-[1px] h-6 bg-white/10 mx-1" /> {/* Vertical Divider */}
    <span className="text-sm font-black text-white/40 tracking-widest uppercase">
      {config.coin_ticker}
    </span>
  </div>
</div>
          <AnimatePresence>
            {error && (
              <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 text-red-400">
                <AlertCircle size={12} />
                <span className="text-[9px] font-black uppercase tracking-widest">{error}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <button 
          disabled={isButtonDisabled} 
          onClick={onStakeClick} 
          className={`relative w-full h-12 rounded-2xl overflow-hidden transition-all ${!isButtonDisabled ? 'active:scale-[0.98]' : 'opacity-40 grayscale pointer-events-none'}`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-500 to-pink-600" />
          <div className="absolute inset-[2px] bg-[#0F172A] rounded-[14px] flex items-center justify-center">
            {isLoading ? (
                <Activity size={20} className="animate-spin text-pink-500" />
            ) : (
                <div className="flex items-center gap-3">
                    <PiggyBankIcon size={16} className="text-white" />
                    <span className="text-white font-black text-[11px] uppercase ">Confirm_Stake</span>
                </div>
            )}
          </div>
        </button>
      </div>

      {/* History List */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 px-2">
            <BarChart3 size={14} className="text-slate-500" />
            <span className="text-[10px] font-black text-slate-500 uppercase">Active Stakes ({stakingHistory.length})</span>
        </div>

        <div className="space-y-3">
            {stakingHistory.length > 0 ? (
                stakingHistory?.map((stake: any) => (
                    <StakeItem key={stake._id} stake={stake} />
                ))
            ) : (
                <div className="py-10 border-2 border-dashed border-slate-800 rounded-3xl flex flex-col items-center justify-center opacity-50">
                    <TrendingUp size={24} className="text-slate-700 mb-2" />
                    <p className="text-[9px] font-black text-slate-600 uppercase">Zero_Active_Stakes</p>
                </div>
            )}
        </div>
      </div>
    </motion.div>
  );
};

export default StakingProtocol;