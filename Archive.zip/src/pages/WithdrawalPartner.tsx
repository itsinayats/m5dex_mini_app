import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowLeft, 
  Zap, 
  AlertCircle,
  Cpu,
  ShieldCheck,
  Activity,
  Terminal as TerminalIcon,
  Percent,
  Layers
} from "lucide-react";
import { useAppContext } from "../context/AppContext";
import { useNavigate } from "react-router-dom";

const PartnerWithdrawal: React.FC = () => {
  const { user, handleWithdrawPartner, isLoading,config } = useAppContext();
  const navigate = useNavigate();

  const [amount, setAmount] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  const partnerBalance = user?.partner_balance || 0;

  useEffect(() => {
    const numAmount = parseFloat(amount);
    const hasInsufficientFunds = numAmount > partnerBalance;
    const isInvalidNumber = isNaN(numAmount) || numAmount <= 0;
    
    if (hasInsufficientFunds) {
      setError("ERR_INSUFFICIENT_CREDITS");
    } else {
      setError(null);
    }

    setIsButtonDisabled(isLoading || isInvalidNumber || hasInsufficientFunds);
  }, [amount, partnerBalance, isLoading]);

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  const setMax = () => setAmount(partnerBalance.toString());

  const onWithdrawClick = async () => {
    const success = await handleWithdrawPartner(parseFloat(amount));
    if (success) setAmount("");
  };

  if (!user) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="px-6 space-y-6 pb-24 text-slate-200"
    >
      {/* Protocol Header */}
      <div className="flex items-center justify-between pt-6">
        <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate(-1)} 
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-slate-900 border-2 border-slate-800 text-slate-400 active:scale-90 transition-all shadow-[0_4px_10px_rgba(0,0,0,0.3)]"
            >
                <ArrowLeft size={20} />
            </button>
            <div>
                <h1 className="text-[10px] font-black uppercase  text-slate-500  ">Financial_Relay_v2</h1>
                <p className="text-sm font-black text-white uppercase tracking-tight">Partner_Payout</p>
            </div>
        </div>
        <div className="w-10 h-10 bg-black border-2 border-slate-800 rounded-xl flex items-center justify-center relative">
            <Cpu size={18} className="text-cyan-500" />
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-500 rounded-full border-2 border-[#0F172A] animate-pulse" />
        </div>
      </div>

      {/* Hero: Revenue Stream Monitor (Mechanical Rainbow) */}
      <div className="relative bg-[#0F172A] border-2 border-slate-800 rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        {/* Spectral Energy Rail */}
        <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-pink-500 via-purple-500 via-blue-500 via-cyan-500 via-emerald-500 via-yellow-500 to-red-500" />
        
        <div className="p-8 text-center relative">
          <div className="flex justify-center mb-3">
             <div className="px-3 py-1 bg-black border border-slate-800 rounded-full flex items-center gap-2">
                <Activity size={10} className="text-emerald-500" />
                <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">Active_Stream_Authorized</span>
             </div>
          </div>
          
          <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.4em] mb-1  ">Claimable_Commission</p>
          <h2 className="text-5xl font-black tracking-tighter   text-white tabular-nums">
            {partnerBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </h2>
          <div className="mt-3 inline-block bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent font-black text-[10px] uppercase ">
            TON
          </div>
        </div>

        {/* Micro-Grid Background Overlay */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
             style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 0)', backgroundSize: '16px 16px' }} />
      </div>

      {/* Extraction Interface */}
      <div className="space-y-4">
        <div className="bg-black/40 border-2 border-slate-800 rounded-3xl p-6 space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <TerminalIcon size={14} className="text-cyan-500" />
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">INPUT_AMOUNT</span>
            </div>
            <button 
              onClick={setMax} 
              className="text-[9px] font-black text-white uppercase tracking-widest bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg hover:bg-slate-700 transition-all active:scale-95 shadow-lg"
            >
              Max
            </button>
          </div>

          <div className="relative group">
            <input 
              type="text"
              value={amount}
              onChange={handleAmountChange}
              placeholder="0.00"
              className={`w-full bg-black border-2 ${error ? 'border-red-500/50' : 'border-slate-800 focus:border-cyan-500/50'} rounded-2xl p-6 text-3xl font-black text-white focus:outline-none transition-all placeholder:text-slate-900 font-mono  `}
            />
            <div className="absolute right-6 top-1/2 -translate-y-1/2 flex flex-col items-end">
              <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest mb-1">UNIT</span>
              <span className="text-sm font-black text-cyan-500 uppercase  ">TON</span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -5 }} 
                animate={{ opacity: 1, x: 0 }} 
                className="flex items-center gap-2 px-2 py-2 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400"
              >
                <AlertCircle size={12} />
                <span className="text-[9px] font-black uppercase tracking-[0.1em]">{error}</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Rainbow Execution Button */}
        <button 
          disabled={isButtonDisabled}
          onClick={onWithdrawClick}
          className={`relative group w-full h-16 rounded-2xl overflow-hidden transition-all ${
            !isButtonDisabled ? 'active:scale-95' : 'opacity-30 grayscale'
          }`}
        >
          {/* Rainbow Gradient Background */}
          <div className={`absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-500 via-blue-500 via-cyan-500 ${!isButtonDisabled ? 'animate-gradient-x' : ''}`} />
          
          {/* Inner Dark Mask */}
          <div className="absolute inset-[2px] bg-[#0F172A] rounded-[14px] flex items-center justify-center group-hover:bg-transparent transition-colors duration-300">
            {isLoading ? (
              <Activity size={20} className="animate-spin text-white" />
            ) : (
              <div className="flex items-center gap-3">
                <Zap size={16} className={`text-white transition-transform duration-500 ${!isButtonDisabled && 'fill-white group-hover:scale-125'}`} />
                <span className="text-white font-black text-[11px] uppercase ">Place Withdrawal</span>
              </div>
            )}
          </div>
        </button>
      </div>

      {/* Protocol Specs (Industrial Information) */}
      <div className="bg-black/40 border-2 border-slate-800 rounded-3xl p-6 space-y-6">
        <div className="flex items-center gap-2">
            <ShieldCheck size={14} className="text-slate-500" />
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Protocol_Clearance</span>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl shadow-inner">
                <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-2">Commission_Rate</p>
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-black border border-emerald-500/30 rounded-lg flex items-center justify-center text-emerald-500">
                        <Percent size={14} />
                    </div>
                    <span className="text-sm font-black text-white  ">{config.partner_comission_percentage_ton}%</span>
                </div>
            </div>
            
            <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl shadow-inner">
                <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-2">Network_Mode</p>
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-black border border-cyan-500/30 rounded-lg flex items-center justify-center text-cyan-400">
                        <Zap size={14} />
                    </div>
                    <span className="text-sm font-black text-white   uppercase tracking-tighter">Instant</span>
                </div>
            </div>
        </div>

        <div className="p-4 bg-red-500/5 border-2 border-red-500/10 rounded-2xl flex gap-4">
            <AlertCircle size={18} className="text-red-500/50 shrink-0" />
            <p className="text-[8px] font-black text-slate-600 uppercase leading-relaxed tracking-widest  ">
              [CRITICAL] Payouts are computed via {config.coin_ticker} real-time modules. Ensure your target TON_RELAY is synchronized before confirming withdrawal.
            </p>
        </div>
      </div>

    </motion.div>
  );
};

export default PartnerWithdrawal;