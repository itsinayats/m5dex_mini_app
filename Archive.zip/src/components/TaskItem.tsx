import React, { useState } from "react";
import {
  Twitter,
  Wallet,
  Zap,
  Loader2,
  ShieldCheck,
  Send,
  Users,
  Cpu,
  Play,
  Gift,
  Instagram,
  Youtube,
} from "lucide-react";

import { Task } from "../types";
import { useAppContext } from "../context/AppContext";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

import YouTubeTaskModal from "./YouTubeTaskModal";

interface TaskItemProps {
  task: Task;
  onComplete: (task: Task) => void;
}

const TaskItem: React.FC<TaskItemProps> = ({ task, onComplete }) => {
  const [loading, setLoading] = useState(false);

  // youtube
  const [showYT, setShowYT] = useState(false);
  const [ytVerified, setYtVerified] = useState(false);

  // completed task but reward not claimed yet
  const [taskReadyToClaim, setTaskReadyToClaim] = useState(false);

  const navigate = useNavigate();

  const {
    user,
    checkChatMember,
    config,
    setShowTonTaskModal,
  } = useAppContext();

  // ================= ICON =================
  const getTaskIcon = () => {
    const t = task.type;

    if (t === "youtube") return <Play size={18} />;
    if (t === "twitter") return <Twitter size={18} />;
    if (t === "telegram") return <Send size={18} />;
    if (t === "ton") return <Wallet size={18} />;
    if (t === "youtube") return <Youtube size={18} />;
    if (t === "instagram") return <Instagram size={18} />;
    if (t === "external") return <Cpu size={18} />;


    return <Users size={18} />;
  };

  // ================= BUTTON ICON =================
  const getButtonIcon = () => {
    // COMPLETED
    if (task.completed_at) {
      return <ShieldCheck size={18} />;
    }

    // LOADING
    if (loading) {
      return <Loader2 size={18} className="animate-spin" />;
    }

    // READY TO CLAIM
    if (taskReadyToClaim) {
      return <Gift size={18} />;
    }

    // DEFAULT
    return <Play size={18} />;
  };

  // ================= BUTTON STYLE =================
  const getButtonClass = () => {
    if (task.completed_at) {
      return "bg-emerald-500 text-black";
    }

    if (taskReadyToClaim) {
      return "bg-yellow-400 text-black";
    }

    return "bg-white text-black";
  };

  // ================= MAIN ACTION =================
 const handleAction = async () => {
  if (task.completed_at || loading) return;

  setLoading(true);

  try {

    // ================= REFERRAL =================
    if (task.type === "referral") {
      navigate("/friends");
      return;
    }

    // ================= TELEGRAM =================
    if (task.type === "telegram") {

      // FIRST CLICK → OPEN CHANNEL
      if (!taskReadyToClaim) {

        window.Telegram?.WebApp?.openLink(task.link);

        setTimeout(() => {
          setTaskReadyToClaim(true);
          setLoading(false);
        }, 1500);

        return;
      }

      // SECOND CLICK → VERIFY + CLAIM
      const res = await checkChatMember(
        task.chat_id,
        user.id
      );

      console.log("telegram verify =>", res);

      const ok =
        res?.ok &&
        ["member", "administrator", "creator"].includes(
          res?.result?.status
        );

      if (ok) {
        await onComplete(task);
      } else {
        alert("Please join Telegram channel first");
      }

      return;
    }




// ================= TWITTER =================
if (task.type === "twitter") {
      if (!taskReadyToClaim) {
        window.Telegram?.WebApp?.openLink(task.link);

        setTimeout(() => {
          setTaskReadyToClaim(true);
          setLoading(false);
        }, 1500);

        return;
      }

      // CLAIM
      await onComplete(task);
      return;
}


// ================= TWITTER =================
if (task.type === "instagram") {
      if (!taskReadyToClaim) {
        window.Telegram?.WebApp?.openLink(task.link);

        setTimeout(() => {
          setTaskReadyToClaim(true);
          setLoading(false);
        }, 1500);

        return;
      }

      // CLAIM
      await onComplete(task);
      return;
}



    // ================= EXTERNAL =================
    if (task.type === "external") {

      // FIRST CLICK
      if (!taskReadyToClaim) {

         window.Telegram?.WebApp?.openLink(task.link);

        setTimeout(() => {
          setTaskReadyToClaim(true);
          setLoading(false);
        }, 1500);

        return;
      }

      // CLAIM
      await onComplete(task);
      return;
    }

    // ================= YOUTUBE =================
    if (task.type === "youtube") {

      // FIRST CLICK
      if (!taskReadyToClaim) {
        setShowYT(true);
        setLoading(false);
        return;
      }

      // CLAIM
      if (ytVerified) {
        await onComplete(task);
      } else {
        alert("Watch at least 80% of video first");
      }
      return;
    }

    // ================= TON =================
  
        if (task.type === "ton") {
          if (!taskReadyToClaim) {

          setShowTonTaskModal(task.id);

          return;
          }

          // CLAIM
          await onComplete(task);
          return;
      }

        } catch (err) {
        console.log(err);
        } finally {
        setLoading(false);
        }
        };

  return (
    <div className="relative rounded-2xl p-[1px] bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 overflow-hidden">

      <div className="bg-[#0F172A] rounded-2xl p-4 flex items-center justify-between">

        {/* LEFT */}
        <div className="flex items-center gap-3">

          <div className="w-11 h-11 rounded-xl bg-black/40 border border-white/10 flex items-center justify-center text-white">
            {getTaskIcon()}
          </div>

          <div>
            <h4 className="text-white text-xs font-bold">
              {task.title}
            </h4>

            <p className="text-cyan-400 text-xs mt-1">
              +{task.reward} {config.coin_ticker}
            </p>
          </div>
        </div>

        {/* ACTION BUTTON */}
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleAction}
          disabled={loading}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-300 shadow-lg ${getButtonClass()}`}
        >
          {getButtonIcon()}
        </motion.button>
      </div>

      {/* ================= YOUTUBE MODAL ================= */}
      {showYT && (
        <YouTubeTaskModal
          videoId={
            task.link.includes("v=")
              ? task.link.split("v=")[1].split("&")[0]
              : task.link
          }
          onClose={() => setShowYT(false)}
          onComplete={() => {
            // user watched 80%
            setYtVerified(true);

            // show claim button
            setTaskReadyToClaim(true);

            // close modal
            setShowYT(false);
          }}
        />
      )}
    </div>
  );
};

export default TaskItem;