export const MINING_DURATION = 3 * 60 * 60 * 1000;

export const MINING_PLANS = [
  { mult: 3, price: "5.0 TON", desc: "Triple your mining power", pph: 300 },
  { mult: 10, price: "15.0 TON", desc: "Extreme mining boost", pph: 1000 },
  { mult: 50, price: "50.0 TON", desc: "Whale mining speed", pph: 5000 },
  { mult: 100, price: "90.0 TON", desc: "God-tier mining speed", pph: 10000 },
  { mult: 500, price: "400.0 TON", desc: "Legendary mining speed", pph: 50000 },
];

export const RANK_PLANS = [
  { amount: 100000, price: "1.0 TON", ton: 1.0, desc: "Starter Rank Boost" },
  { amount: 500000, price: "4.5 TON", ton: 4.5, desc: "Pro Rank Boost" },
  { amount: 1000000, price: "8.0 TON", ton: 8.0, desc: "Elite Rank Boost" },
  { amount: 5000000, price: "35.0 TON", ton: 35.0, desc: "Whale Rank Boost" },
  { amount: 10000000, price: "60.0 TON", ton: 60.0, desc: "Legendary Rank Boost" },
];

export const CHECKIN_DAYS = Array.from({ length: 60 }, (_, i) => ({
  day: i + 1,
  reward: 100 + (i * 50)
}));
